# IGL-nano
Минимальное WASM-ядро для максимальной производительности
Minimal WASM core for maximum performance
## Быстрый старт
```bash
curl https://igl-nano.dev/install.sh | sh  # Пример для IoT