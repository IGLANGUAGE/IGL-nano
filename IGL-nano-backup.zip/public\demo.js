import { add } from 'igl-nano';
console.log("3 + 4 =", add(3, 4));